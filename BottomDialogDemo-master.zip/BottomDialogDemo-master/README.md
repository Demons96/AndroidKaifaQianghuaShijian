# DialogFragment实现底部弹窗

DialogFragment底部弹窗的开发模板，Created by C.L. Wang
