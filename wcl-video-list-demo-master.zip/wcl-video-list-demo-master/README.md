# wcl-video-list-demo

朋友圈视频的滚动播放功能 开发标准模板，Created by C.L. Wang
